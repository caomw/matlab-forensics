function [h0] = h0model(x, p0, bin0)



return