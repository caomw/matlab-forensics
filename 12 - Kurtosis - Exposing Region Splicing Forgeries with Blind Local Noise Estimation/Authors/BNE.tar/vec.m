function x = vec(y)
x = y(:);
