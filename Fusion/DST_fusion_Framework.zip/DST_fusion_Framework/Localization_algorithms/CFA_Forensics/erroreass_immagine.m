function [ erroreass_immagine ] = erroreass_immagine( e_red,e_green,e_blue )


erroreass_immagine = (e_red)^2+2*(e_green)^2+(e_blue)^2;