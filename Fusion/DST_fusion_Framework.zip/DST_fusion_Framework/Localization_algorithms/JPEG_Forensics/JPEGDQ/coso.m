pause(0.05);
a = 10;
quit