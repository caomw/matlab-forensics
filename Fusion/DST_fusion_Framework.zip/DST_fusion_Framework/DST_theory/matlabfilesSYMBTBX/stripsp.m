function[string] = stripsp(string)
    strrep(string, ' ','');
end
