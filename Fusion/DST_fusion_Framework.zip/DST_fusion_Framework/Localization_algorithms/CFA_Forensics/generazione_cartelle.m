simulation_folder = '/users/ferrara/Desktop/Simulazioni8x8';
mkdir(simulation_folder);

mkdir([simulation_folder,'/Sintetiche_128/Mappe']);
mkdir([simulation_folder,'/Sintetiche_128/Parametri']);
mkdir([simulation_folder,'/Sintetiche_128/Verosimiglianza']);
mkdir([simulation_folder,'/Sintetiche_128/ROC']);

mkdir([simulation_folder,'/Sintetiche_64/Mappe']);
mkdir([simulation_folder,'/Sintetiche_64/Parametri']);
mkdir([simulation_folder,'/Sintetiche_64/Verosimiglianza']);
mkdir([simulation_folder,'/Sintetiche_64/ROC']);

mkdir([simulation_folder,'/Sintetiche_32/Mappe']);
mkdir([simulation_folder,'/Sintetiche_32/Parametri']);
mkdir([simulation_folder,'/Sintetiche_32/Verosimiglianza']);
mkdir([simulation_folder,'/Sintetiche_32/ROC']);

mkdir([simulation_folder,'/TIFF_128/Mappe']);
mkdir([simulation_folder,'/TIFF_128/Parametri']);
mkdir([simulation_folder,'/TIFF_128/Verosimiglianza']);
mkdir([simulation_folder,'/TIFF_128/ROC']);

mkdir([simulation_folder,'/TIFF_64/Mappe']);
mkdir([simulation_folder,'/TIFF_64/Parametri']);
mkdir([simulation_folder,'/TIFF_64/Verosimiglianza']);
mkdir([simulation_folder,'/TIFF_64/ROC']);

mkdir([simulation_folder,'/TIFF_32/Mappe']);
mkdir([simulation_folder,'/TIFF_32/Parametri']);
mkdir([simulation_folder,'/TIFF_32/Verosimiglianza']);
mkdir([simulation_folder,'/TIFF_32/ROC']);

mkdir([simulation_folder,'/JPEG100_128/Mappe']);
mkdir([simulation_folder,'/JPEG100_128/Parametri']);
mkdir([simulation_folder,'/JPEG100_128/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG100_128/ROC']);

mkdir([simulation_folder,'/JPEG100_64/Mappe']);
mkdir([simulation_folder,'/JPEG100_64/Parametri']);
mkdir([simulation_folder,'/JPEG100_64/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG100_64/ROC']);

mkdir([simulation_folder,'/JPEG100_32/Mappe']);
mkdir([simulation_folder,'/JPEG100_32/Parametri']);
mkdir([simulation_folder,'/JPEG100_32/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG100_32/ROC']);

mkdir([simulation_folder,'/JPEG95_128/Mappe']);
mkdir([simulation_folder,'/JPEG95_128/Parametri']);
mkdir([simulation_folder,'/JPEG95_128/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG95_128/ROC']);

mkdir([simulation_folder,'/JPEG95_64/Mappe']);
mkdir([simulation_folder,'/JPEG95_64/Parametri']);
mkdir([simulation_folder,'/JPEG95_64/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG95_64/ROC']);

mkdir([simulation_folder,'/JPEG95_32/Mappe']);
mkdir([simulation_folder,'/JPEG95_32/Parametri']);
mkdir([simulation_folder,'/JPEG95_32/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG95_32/ROC']);

mkdir([simulation_folder,'/JPEG90_128/Mappe']);
mkdir([simulation_folder,'/JPEG90_128/Parametri']);
mkdir([simulation_folder,'/JPEG90_128/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG90_128/ROC']);

mkdir([simulation_folder,'/JPEG90_64/Mappe']);
mkdir([simulation_folder,'/JPEG90_64/Parametri']);
mkdir([simulation_folder,'/JPEG90_64/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG90_64/ROC']);

mkdir([simulation_folder,'/JPEG90_32/Mappe']);
mkdir([simulation_folder,'/JPEG90_32/Parametri']);
mkdir([simulation_folder,'/JPEG90_32/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG90_32/ROC']);

mkdir([simulation_folder,'/JPEG85_128/Mappe']);
mkdir([simulation_folder,'/JPEG85_128/Parametri']);
mkdir([simulation_folder,'/JPEG85_128/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG85_128/ROC']);

mkdir([simulation_folder,'/JPEG85_64/Mappe']);
mkdir([simulation_folder,'/JPEG85_64/Parametri']);
mkdir([simulation_folder,'/JPEG85_64/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG85_64/ROC']);

mkdir([simulation_folder,'/JPEG85_32/Mappe']);
mkdir([simulation_folder,'/JPEG85_32/Parametri']);
mkdir([simulation_folder,'/JPEG85_32/Verosimiglianza']);
mkdir([simulation_folder,'/JPEG85_32/ROC']);